package exceptionhandling;

public class NestedTryCatchDemo {

	public static void main(String[] args) {
		NestedTryCatch.check();
	}

}